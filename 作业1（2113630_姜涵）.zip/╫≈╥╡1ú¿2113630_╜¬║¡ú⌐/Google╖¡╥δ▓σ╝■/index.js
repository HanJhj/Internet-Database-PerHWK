﻿ const translate = document.getElementById('translate');
        const auto_pronunciation = document.getElementById('auto-pronunciation');
        const input = document.getElementById('input');
        const output = document.getElementById('output');
        let   timer;

        
        // 初始化自动发音的状态并储存到localStorage
        let is_auto_pronunciation = localStorage.getItem('is_auto_pronunciation');
        if (!is_auto_pronunciation) {
            is_auto_pronunciation = "true" //默认自动发音
            localStorage.setItem('is_auto_pronunciation', is_auto_pronunciation)
        }
        

        input.oninput = function(ev) {
            // 减少不必要的请求
            if (timer) {
                clearTimeout(timer);
            }
            timer = setTimeout(() => {
                translateFun(); // 正在输入时的翻译不需要发音
            }, 1500);
        };

        translate.onclick = function () {
            translateFun().then(result => {
                pronunciation(result.speakUrl); // 需要发音
            });
        };

        function changePronunciationBtnText(){
            if (is_auto_pronunciation === 'true') {
                auto_pronunciation.textContent = '自动发音: 开';
                auto_pronunciation.style.backgroundColor = 'rgb(50, 226, 203)';
            } else {
                auto_pronunciation.textContent = '自动发音: 关';
                auto_pronunciation.style.backgroundColor = 'rgb(169, 169, 169)';
            }
        }
        changePronunciationBtnText();

        // 自动翻译的开关
        auto_pronunciation.onclick = function () {
            if (is_auto_pronunciation === 'true') {
                is_auto_pronunciation = 'false'
            } else {
                is_auto_pronunciation = 'true'
            }
            localStorage.setItem('is_auto_pronunciation', is_auto_pronunciation)
            changePronunciationBtnText()
        };

        async function translateFun() {
            let result = await send(input.value);
            if (!result) return {};
            // console.log(result);
            // console.log(result.speakUrl); // 翻译前的语音
            // console.log(result.tSpeakUrl); // 翻译后的语音

            if (result.basic && result.basic.explains) {
                let value = "";
                result.basic.explains.forEach(element => {
                    value += element + '\n'; //让其换行
                });
                output.value = value;
            } else if (result.translation) {
                output.value = result.translation;
            } else {
                output.value = "错误: 没有返回翻译结果!";
            }

            return result;
        };

        function pronunciation(speakUrl) {
            if (is_auto_pronunciation === 'true' && speakUrl) {
                let audio = document.createElement('audio');
                audio.src = speakUrl;
                audio.hidden = true;
                audio.play();
                audio = null;
            }
        }

　　     // from和to可以指定翻译语言,设置Auto为自动检测
        async function send(q, from = 'Auto', to = 'Auto') {
            if (!q) return;
            let result = null;
            await $.ajax({
                url: 'https://aidemo.youdao.com/trans',
                type: 'post',
                dataType: 'json',
                data: {
                    q,
                    from,
                    to,
                },
                success(data) {
                    result = data;
                },
                error() {alert('翻译出错了');}
            });
            return result;
        }